import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def get_target_radius(z):
    """Defines the engine-like bell curve for the pipe radius."""
    return 2.0 + 0.5 * np.sin(z * 0.5) + (z/10)**2

def sdf_cylinder(p, r):
    """Standard SDF for a cylinder along the Z axis."""
    return np.sqrt(p[:, 0]**2 + p[:, 1]**2) - r

def sdf_channel(p, z_height, angle, r_offset, r_channel):
    """SDF for a single cooling channel that follows the engine curve."""
    # Rotate p around Z to align with the channel angle
    ca, sa = np.cos(angle), np.sin(angle)
    x_rot = p[:, 0] * ca - p[:, 1] * sa
    y_rot = p[:, 0] * sa + p[:, 1] * ca
    
    # Offset in X (radial direction)
    return np.sqrt((x_rot - r_offset)**2 + y_rot**2) - r_channel

def fraktal_pipe_field(resolution=50):
    """Generates the SDF field for a pipe with fraktal-like branching channels."""
    z_min, z_max = 0, 10
    x_range = np.linspace(-5, 5, resolution)
    y_range = np.linspace(-5, 5, resolution)
    z_range = np.linspace(z_min, z_max, resolution)
    
    X, Y, Z = np.meshgrid(x_range, y_range, z_range, indexing='ij')
    points = np.stack([X.ravel(), Y.ravel(), Z.ravel()], axis=-1)
    
    # Base Wall
    r_outer = get_target_radius(points[:, 2]) + 0.5
    r_inner = get_target_radius(points[:, 2])
    
    sdf_wall = np.maximum(sdf_cylinder(points, r_outer), -sdf_cylinder(points, r_inner))
    
    # Channels (Simplistic fraktal branching: 4 channels at z<5, 8 channels at z>=5)
    sdf_channels = np.full(points.shape[0], 1e6)
    
    for i in range(8):
        angle = i * (2 * np.pi / 8)
        r_offset = get_target_radius(points[:, 2]) + 0.25
        r_chan = 0.1
        
        # Condition for branching (mocking fraktal logic)
        mask = np.ones(points.shape[0], dtype=bool)
        if i % 2 != 0:
            mask = points[:, 2] > 5.0 # Branching happens halfway
            
        chan_dist = sdf_channel(points, points[:, 2], angle, r_offset, r_chan)
        sdf_channels[mask] = np.minimum(sdf_channels[mask], chan_dist[mask])

    # Final geometry: Wall MINUS Channels
    final_sdf = np.maximum(sdf_wall, -sdf_channels)
    
    return X, Y, Z, final_sdf.reshape(X.shape)

def visualize_cross_section(Z_field, z_idx):
    plt.figure(figsize=(8, 8))
    plt.imshow(Z_field[:, :, z_idx] < 0, extent=[-5, 5, -5, 5], cmap='Blues')
    plt.title(f"Cross-section at Z-index {z_idx}")
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.grid(True)
    plt.show()

if __name__ == "__main__":
    print("Generating Fraktal Pipe SDF Field...")
    X, Y, Z, field = fraktal_pipe_field(resolution=60)
    
    print("Visualizing cross-sections (slices)...")
    # Show two slices to see branching
    # z_idx 10 (low height, 4 channels effectively)
    # z_idx 50 (high height, 8 channels)
    
    # In this mock, we just show the field. 
    # To truly see the result, we'll save several slices as images.
    for i, z_slice in enumerate([15, 45]):
        plt.figure(figsize=(6, 6))
        plt.contourf(X[:, :, z_slice], Y[:, :, z_slice], field[:, :, z_slice], levels=[-1, 0], colors=['#1a73e8'])
        plt.title(f"Engine Cross-section at Z={Z[0,0,z_slice]:.2f}")
        plt.axis('equal')
        plt.savefig(f"c:/Users/r.karpavicius/Documents/Antigravity/Fraktalas/prototype/slice_{i}.png")
        print(f"Saved slice_{i}.png")
    
    print("Prototype complete.")
