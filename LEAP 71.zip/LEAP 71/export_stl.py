# -*- coding: utf-8 -*-
import math
import struct
import os

# === PURE PYTHON MINIMAL STL GENERATOR (NO DEPENDENCIES) ===
# Suderinama su Python 2.7 ir 3.x. Generuoja Binary STL failą.

def get_target_radius(z):
    """Fizikine variklio kreives funkcija."""
    return 3.0 + 0.8 * math.sin(z * 0.4) + (z/4.0)**2

def sdf_engine(x, y, z):
    """SDF laukas: Vamzdis su fraktaliniais kanalais."""
    r_target = get_target_radius(z)
    dist_center = math.sqrt(x*x + y*y)
    
    # Sieneles SDF (0.8mm storis)
    thickness = 0.8
    outer = dist_center - (r_target + thickness)
    inner = -(dist_center - r_target)
    wall_sdf = max(outer, inner)
    
    # Fraktaliniai kanalai
    channel_sdf = 1000.0
    branches = 8
    for i in range(branches):
        angle = (float(i)/branches) * 2 * math.pi + (z * 0.1)
        cx = math.cos(angle) * (r_target + thickness/2.0)
        cy = math.sin(angle) * (r_target + thickness/2.0)
        c_dist = math.sqrt((x-cx)**2 + (y-cy)**2) - 0.25
        channel_sdf = min(channel_sdf, c_dist)
        
    return max(wall_sdf, -channel_sdf)

def write_stl_binary(triangles, out_path):
    """Iraso trikampius i Binary STL faila."""
    with open(out_path, 'wb') as f:
        # Header (80 bytes)
        f.write(struct.pack('80s', b'LEAP 71 CEM Bridge Export'))
        # Number of triangles (4 bytes)
        f.write(struct.pack('<I', len(triangles)))
        
        for tri in triangles:
            # Normal (3 floats)
            f.write(struct.pack('<3f', 0, 0, 0)) # Placeholder normal
            # Vertices (9 floats)
            for v in tri:
                f.write(struct.pack('<3f', v[0], v[1], v[2]))
            # Attribute count (2 bytes)
            f.write(struct.pack('<H', 0))

def generate_voxel_mesh(res=40):
    """Generuoja geometrija naudojant paprasta Voxel-Face algoritma (itin patikima)."""
    size = 10.0
    half = size / 2.0
    step = size / res
    
    triangles = []
    
    print("Skaiciuojamas SDF laukas (rezoliucija %d)..." % res)
    # 3D Grid evaluation
    grid = {}
    for zi in range(res):
        z = -5.0 + zi * step
        for yi in range(res):
            y = -half + yi * step
            for xi in range(res):
                x = -half + xi * step
                grid[(xi, yi, zi)] = sdf_engine(x, y, z) < 0

    print("Generuojami tinklelio trikampiai...")
    # Generate faces for boundary voxels
    for (xi, yi, zi), inside in grid.items():
        if not inside: continue
        
        # Check 6 neighbors. If neighbor is outside or out of bounds, add a face.
        neighbors = [
            (xi+1, yi, zi, [ (1,0,0), (1,1,0), (1,1,1), (1,0,1) ]), # +X
            (xi-1, yi, zi, [ (0,0,0), (0,0,1), (0,1,1), (0,1,0) ]), # -X
            (xi, yi+1, zi, [ (0,1,0), (0,1,1), (1,1,1), (1,1,0) ]), # +Y
            (xi, yi-1, zi, [ (0,0,0), (1,0,0), (1,0,1), (0,0,1) ]), # -Y
            (xi, yi, zi+1, [ (0,0,1), (1,0,1), (1,1,1), (0,1,1) ]), # +Z
            (xi, yi, zi-1, [ (0,0,0), (0,1,0), (1,1,0), (1,0,0) ])  # -Z
        ]
        
        for nxi, nyi, nzi, face_verts in neighbors:
            if not grid.get((nxi, nyi, nzi), False):
                # Add two triangles for the square face
                v = []
                for fv in face_verts:
                    v.append((
                        (-half + (xi + fv[0]) * step),
                        (-half + (yi + fv[1]) * step),
                        (-5.0 + (zi + fv[2]) * step)
                    ))
                triangles.append([v[0], v[1], v[2]])
                triangles.append([v[0], v[2], v[3]])
                
    return triangles

if __name__ == "__main__":
    import time
    # Naudojame laiką pavadinime, kad išvengtume failų rakinimo problemų
    timestamp = int(time.time() % 10000)
    out_file = "fraktalas_%d.stl" % timestamp
    
    print("=== PURE PYTHON STL EXPORTER ===")
    try:
        tris = generate_voxel_mesh(res=50)
        print("Sukurta trikampiu: %d" % len(tris))
        
        write_stl_binary(tris, out_file)
        print("\nSEKME: Failas sukurtas: %s" % os.path.abspath(out_file))
        print("SolidWorks importas: File -> Open -> fraktalas_%d.stl -> Options -> Import as Solid Body" % timestamp)
    except Exception as e:
        print("\nKLAIDA gaminant faila: %s" % str(e))
